(function () {
  'use strict';

  // Add your code here...
})();
